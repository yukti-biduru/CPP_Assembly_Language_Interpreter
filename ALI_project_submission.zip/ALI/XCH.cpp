#include "XCH.h"
#include <iostream>

using namespace std;

XCH::XCH(string argument)
{
	argValue = argument;
	printString = "XCH";
}

void XCH::execute()
{
	string temp = hardware.register_a;
	hardware.register_a = hardware.register_b;
	hardware.register_b = temp;
}