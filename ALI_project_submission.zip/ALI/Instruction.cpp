#include "Instruction.h"
#include <iostream>


using namespace std;

	
	Instruction::Instruction()
	{
		hardware = Hardware();
	}

	void Instruction::print()
	{
		cout << printString << " " << argValue;
	}

