#ifndef Instruction_h
#define Instruction_h

#include <iostream>
#include "Hardware.h"

using namespace std;

class Instruction 
{
public :
	string printString;
	string argValue;
	Hardware hardware;

	Instruction();
	void print();
	virtual void execute() = 0;
};
#endif
