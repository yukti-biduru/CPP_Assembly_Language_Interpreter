#include "LDI.h"
#include <iostream>

using namespace std;

LDI::LDI(string argument)
{
	argValue = argument;
	printString = "LDI";
}

void LDI::execute()
{
	hardware.register_a = argValue;
}